/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import dbUtils.DbConn;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.record.StringData;
import model.record.StringDataList;

/**
 *
 * @author KEYUR
 */
public class WebOtherView {
    public static StringDataList getAllUsers(DbConn dbc) {

        //PreparedStatement stmt = null;
        //ResultSet results = null;
        StringDataList sdl = new StringDataList();
        try {
            String sql= "SELECT user_record_id, imageLogo, record_name, total_games, runs, bat_ave, debut_date, user_record.web_user_id, user_email " +
                    "FROM web_user, user_record where web_user.web_user_id = user_record.web_user_id " +
                            "ORDER BY user_record_id";
      
            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
            ResultSet results = stmt.executeQuery();
            while (results.next()) {
                sdl.add(results);
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            StringData sd = new StringData();
            sd.errorMsg = "Exception thrown in WebOtherView.allUsersAPI(): " + e.getMessage();
            sdl.add(sd);
        }
        return sdl;
    }
}
