package model.record;

import dbUtils.FormatUtils;
import java.sql.ResultSet;


/* The purpose of this class is just to "bundle together" all the 
 * character data that the user might type in when they want to 
 * add a new Customer or edit an existing customer.  This String
 * data is "pre-validated" data, meaning they might have typed 
 * in a character string where a number was expected.
 * 
 * There are no getter or setter methods since we are not trying to
 * protect this data in any way.  We want to let the JSP page have
 * free access to put data in or take it out. */
public class StringData { 

    public String userRecordId = "";
    public String image = "";
    public String recordName = "";
    public String totalGames = "";
    public String runs = "";
    public String batAvg = "";
    public String debutDate = "";
    public String webUserId = "";// Foreign Key 
    
    public String userEmail = "";
    

    public String errorMsg = "";

    // default constructor leaves all data members with empty string (Nothing null).
    public StringData() {
    }

    // overloaded constructor sets all data members by extracting from resultSet.
    public StringData(ResultSet results) {
        try {
            // plainInteger returns integer converted to string with no commas.
            this.webUserId = FormatUtils.plainInteger(results.getObject("web_user_id"));
            this.recordName = FormatUtils.formatString(results.getObject("record_name"));
            this.totalGames = FormatUtils.plainInteger(results.getObject("total_games"));
            this.image = FormatUtils.formatString(results.getObject("imageLogo"));
            this.runs = FormatUtils.plainInteger(results.getObject("runs"));
            this.batAvg = FormatUtils.formatFloat(results.getObject("bat_ave"));
            this.debutDate = FormatUtils.formatDate(results.getObject("debut_date"));
            this.userRecordId = FormatUtils.plainInteger(results.getObject("user_record_id"));
            this.userEmail = FormatUtils.formatString(results.getObject("user_email"));
        } catch (Exception e) {
            this.errorMsg = "Exception thrown in model.webUser.StringData (the constructor that takes a ResultSet): " + e.getMessage();
        }
    }

    public int getCharacterCount() {
        String s = this.webUserId + this.recordName + this.totalGames + this.image + this.image + this.runs
                + this.batAvg + this.debutDate + this.userRecordId;
        return s.length();
    }

    public String toString() {
        return "Web User Id:" + this.webUserId
                + ", Record Name " + this.recordName
                + ", Total Games " + this.totalGames
                + ", runs: " + this.runs
                + ", Image: " + this.image
                + ", Batting Ave: " + this.batAvg
                + ", Debut Date: " + this.debutDate
                + ", User Role Id: " + this.userRecordId
                + ", User Email: " + this.userEmail;
    }
}
