/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.webUser;

import dbUtils.FormatUtils;
import java.sql.ResultSet;

/**
 *
 * @author KEYUR
 */
public class StringOtherData {
    public String webUserId = "";
    public String userEmail = "";
    public String userPassword = "";
    public String image = "";
    public String birthday = "";
    public String membershipFee = "";
    public String recordId = "";   // Foreign Key
    public String recordName = ""; // getting it from joined other table.
    public String totalGames = "";
    
    public String errorMsg = "";

    // default constructor leaves all data members with empty string (Nothing null).
    public StringOtherData() {
    }

    // overloaded constructor sets all data members by extracting from resultSet.
    public StringOtherData(ResultSet results) {
        try {
            // plainInteger returns integer converted to string with no commas.
            this.webUserId = FormatUtils.plainInteger(results.getObject("web_user_id"));
            this.userEmail = FormatUtils.formatString(results.getObject("user_email"));
            this.userPassword = FormatUtils.formatString(results.getObject("user_password"));
            this.image = FormatUtils.formatString(results.getObject("image"));
            this.birthday = FormatUtils.formatDate(results.getObject("birthday"));
            this.membershipFee = FormatUtils.formatDollar(results.getObject("membership_fee"));
            this.recordId = FormatUtils.plainInteger(results.getObject("user_record_id"));
            this.recordName = FormatUtils.formatString(results.getObject("record_name"));
            this.totalGames = FormatUtils.plainInteger(results.getObject("total_games"));
        } catch (Exception e) {
            this.errorMsg = "Exception thrown in model.webUser.StringOtherData (the constructor that takes a ResultSet): " + e.getMessage();
        }
    }

    public int getCharacterCount() {
        String s = this.webUserId + this.userEmail + this.userPassword + this.image + this.birthday
                + this.membershipFee + this.recordId + this.recordName + this.totalGames;
        return s.length();
    }

    public String toString() {
        return "Web User Id:" + this.webUserId
                + ", User Email: " + this.userEmail
                + ", User Password: " + this.userPassword
                + ", Image: " + this.image
                + ", Birthday: " + this.birthday
                + ", Membership Fee: " + this.membershipFee
                + ", User Record Id: " + this.recordId
                + ", Record Name: " + this.recordName
                + ", Total Games: " + this.totalGames;
    }
}
