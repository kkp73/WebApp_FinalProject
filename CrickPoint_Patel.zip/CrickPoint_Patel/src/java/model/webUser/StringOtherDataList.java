/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.webUser;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author KEYUR
 */
public class StringOtherDataList {
    public String dbError = "";
    public ArrayList<StringOtherData> webOtherList = new ArrayList();

    // Default constructor leaves StringDataList objects nicely set with properties 
    // indicating no database error and 0 elements in the list.
    public StringOtherDataList() {
    }

    // Adds one StringData element to the array list of StringData elements
    public void add(StringOtherData stringOtherData) {
        this.webOtherList.add(stringOtherData);
    }

    // Adds creates a StringData element from a ResultSet (from SQL select statement), 
    // then adds that new element to the array list of StringData elements.
    public void add(ResultSet results) {
        StringOtherData sd = new StringOtherData(results);
        this.webOtherList.add(sd);
    }
}
