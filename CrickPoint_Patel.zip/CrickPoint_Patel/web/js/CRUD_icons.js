var CRUD_icons =  {}; // empty object, global

// This is the place the HTML coder can change / redirect to whatever icons they want.
// public properties of global object.
CRUD_icons.delete = "icons/delete.png";
CRUD_icons.insert = "icons/insert.png";
CRUD_icons.update = "icons/update.png";
CRUD_icons.view = "icons/view.png";
