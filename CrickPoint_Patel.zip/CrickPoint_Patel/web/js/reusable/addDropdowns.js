function addDropdowns (params) {
    var contentName = params.dropContent || "dropContent";
    var headerName = params.dropHeader || "dropHeader";
    var visibleName = params.show || "show";
    var invisibleName = params.hide || "hide";
    window.onclick = function (event) {
        var dropContents = document.getElementsByClassName(contentName);
        if (event.target.classList.contains(headerName)) {
            var ele = event.target.parentElement.getElementsByClassName(contentName)[0];
            //If the element being clicked on is a dropHeader, then toggle its contents and hide any other dropContents
            toggle(ele);
            for (var i = 0; i < dropContents.length; i++) {
                if (dropContents[i] !== ele)
                    hide(dropContents[i]);
            }
        } else {
            //If the click is from anywhere else on the screen then just close very dropContent
            for (var i = 0; i < dropContents.length; i++) {
                hide(dropContents[i]);
            }
        }
        function show(element) {
            element.classList.remove(invisibleName);
            element.classList.add(visibleName);
        }
        function hide(element) {
            element.classList.remove(visibleName);
            element.classList.add(invisibleName);
        }
        function toggle(element) {
            if (element.classList.contains(visibleName))
                hide(element);
            else
                show(element);
        }
    };
}