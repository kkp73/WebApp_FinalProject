function routeFw (params) {
    var contentName = params.contentName || "content";
    var startingHash = params.startingLink || "#/home";
    if (!params.routingTable || params.routingTable.length < 1) {
        alert("params object must specify array 'routeTable' with at least one element");
        return;
    }
    var routingTable = params.routingTable;
    
    function inject(x) {
        document.getElementById(contentName).innerHTML = "";
        document.getElementById(contentName).appendChild(x);
    }
    
    function parsePath(path) {
        var obj = {
            param: "",
            funcName: path
        };
        var n = path.lastIndexOf("/"); // n = -1 means no '/', a normal path, e.g. '#/home', would have n = 1
        if (n > 1) { // there is a parameter
            obj.param = path.substring(n + 1);
            obj.funcName = path.substring(0, n);
        }
        return obj;
    }
    
    function router() {
        var path = location.hash;
        var ele;
        var pathObj = parsePath(path);
        
        if (!routingTable[pathObj.funcName]) { // the funcName of the URL isn't in the routing table -> error
            ele = document.createElement("div");
            ele.innerHTML = "<p>Error: unknown link '" + pathObj.funcName + "' was never added to the routing table.</p>";
        } else if (pathObj.param.length > 0) { // if this URL has a parameter
            ele = routingTable[pathObj.funcName](pathObj.param);
        } else { // This is a "regular" URL with no parameters, so dont pass any parameters into 
            var ele = routingTable[pathObj.funcName]();
        }
        
        inject(ele);
    }
    
    window.addEventListener('hashchange', router);
    location.hash = "xxxxxxx";
    location.hash = startingHash;
}