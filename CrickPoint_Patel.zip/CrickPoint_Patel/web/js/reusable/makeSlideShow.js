function makeSlideShow(picObjList) {

    var slideShow = document.createElement("div");

    var div = document.createElement("div");
    slideShow.appendChild(div);

    var myImage = document.createElement("img");
    div.append(myImage);
    
    var myCaption = document.createElement("span");
    myCaption.setAttribute("class", "caption");
    slideShow.appendChild(myCaption);
    
    var breakLine = document.createElement("br");
    slideShow.appendChild(breakLine);

    var backButton = document.createElement("button");
    backButton.innerHTML = " &lt; ";
    slideShow.appendChild(backButton);

    var fwdButton = document.createElement("button");
    fwdButton.innerHTML = " &gt; ";
    slideShow.appendChild(fwdButton);

    var picNum = 0;
    setPic();

    function setPic() {
        myImage.src = picObjList[picNum].image;
        myCaption.innerHTML = picObjList[picNum].caption;
    }

    function nextPic() {

        if (picNum < picObjList.length - 1) {
            picNum++;
        }
        else{
            picNum = 0;
        }
        setPic();
    }

    function prevPic() {

        if (picNum > 0) {
            picNum--;
        }
        else{
            picNum = picObjList.length - 1;
        }
        setPic();
    }

    backButton.onclick = prevPic;
    fwdButton.onclick = nextPic;

    slideShow.setPicNum = function (newNum) {
        if ((newNum >= 0) && (newNum < picObjList.length)) {
            picNum = newNum;
            setPic();
        }
    };
    return slideShow;
}