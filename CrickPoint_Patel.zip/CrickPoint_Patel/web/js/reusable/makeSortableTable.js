function makeSortableTable(list, sortOrderPropName, order, sortIcon) {

    function jsSort(list, byProperty, order) {

        list.sort(

                function (q, z) {  
                    var qVal = convert(q[byProperty]);
                    var zVal = convert(z[byProperty]);

                    var c = 0;
                    if (qVal > zVal) {
                        if(order === "Forword"){
                            c = 1;
                        }
                        else{
                            c = -1;
                        }
                        
                    } else if (qVal < zVal) {
                        if(order === "Forword"){
                           c = -1; 
                        }
                        else{
                            c = 1;
                        }
                    }
                    console.log("comparing " + qVal + " to " + zVal + " is " + c);
                    return c;
                }
        );

        function convert(s) {

            if (!s || s.length === 0) {
                return -1;
            }

            var parsedDate = Date.parse(s);
            if (isNaN(s) && !isNaN(parsedDate)) {
                return parsedDate;
            } else {
                var tmp = s;
                console.log("tmp is " + tmp);
                tmp = tmp.replace("$", "");
                tmp = tmp.replace(",", "");
                if (isNaN(tmp)) { 
                    return s.toUpperCase();
                } else {
                    return Number(tmp);
                }
            }
        }
    }

    function isToShow(obj, searchKey) {
        if (!searchKey || searchKey.length === 0) {
            return true;
        }
        var searchKeyUpper = searchKey.toUpperCase();
        for (var prop in obj) {
            var propVal = obj[prop]; 
            console.log("checking if " + searchKeyUpper + " is in " + propVal);
            var propValUpper = propVal.toUpperCase();
            if (propValUpper.includes(searchKeyUpper)) {

                if (!propValUpper.includes("<IMG")) {
                    console.log("yes it is inside");
                    return true;
                }
            }
        }
        console.log("no it is not inside");
        return false;
    } 
    function addToRow(eleType, row, data, alignment) {
        var ele = document.createElement(eleType);
        ele.innerHTML = data;
        ele.style.textAlign = alignment;
        row.appendChild(ele);
        return ele;
    }

    function alignment(val) {

        var parsedDate = Date.parse(val);
        if (isNaN(val) && (!isNaN(parsedDate))) {
            return "center";
        }

        if (val.toUpperCase().includes("<IMG")) {
            console.log('is center');
            return "center";
        }

        var possibleNum = val.replace("$", "");
        possibleNum = possibleNum.replace(",", "");
        if (isNaN(possibleNum)) {
            return "left";
        }
        return "right";

    }

    function addTableHead(table, list) {
 
        var tableHead = document.createElement("thead");
        table.appendChild(tableHead);

        var tableHeadRow = document.createElement("tr");
        tableHead.appendChild(tableHeadRow);
 
        var obj = list[0];
        for (var prop in obj) {
            console.log("setting the sort onclick for column " + prop);
            var iconProp = "<img src='" + sortIcon + "'/> " + prop;
            var colHead = addToRow("th", tableHeadRow, iconProp, alignment(obj[prop]));

            colHead.sortPropName = prop;
            colHead.order = "Forword";
            colHead.onclick = function () {

                console.log("ready to sort by " + this.sortPropName);
                addTableBody(table, list, this.sortPropName, this.order, searchInput.value);
                if(this.order === "Forword"){
                    this.order = "Reverse";
                }else{
                    this.order = "Forword";
                }
            };
        }
    }

    function addTableBody(table, list, sortOrderPropName, order, filterValue) {

        var oldBody = table.getElementsByTagName("tbody");
        if (oldBody[0]) {
            console.log("ready to remove oldBody");
            table.removeChild(oldBody[0]);
        }
        
        var filteredList = [];
        
        for (var i in list) {
            if (isToShow(list[i], filterValue)) {
              filteredList.push(list[i]);  
            }
            
        }
        jsSort(filteredList, sortOrderPropName, order);

        var tableBody = document.createElement("tbody");
        table.appendChild(tableBody);

        for (var i in filteredList) {
            var tableRow = document.createElement("tr");
            tableBody.appendChild(tableRow);

            var obj = filteredList[i];
            for (var prop in obj) {
                addToRow("td", tableRow, obj[prop], alignment(obj[prop]));
            }
            var td = Utils.make({
                htmlTag: "td",
                parent: tableRow
            });
            var img = Utils.make({
                htmlTag: "img",
                parent: td
            });
            img.src = CRUD_icons.update;
            if(obj.record === undefined)
                img.userId = obj.userId;
            else
                img.userRecordId = obj.record.split("&nbsp;")[0];
            img.onclick = function () {
                if(obj.record === undefined)
                    window.location.hash = "#/userUpdate/" + this.userId;
                else
                    window.location.hash = "#/userRecordUpdate/" + this.userRecordId;
            };
            var td = Utils.make({
                htmlTag: "td",
                parent: tableRow
            });
            var img = Utils.make({
                htmlTag: "img",
                parent: td
            });
            img.src = CRUD_icons.delete;
            if(obj.record === undefined)
                img.userId = obj.userId;
            else
                img.userRecordId = obj.record.split("&nbsp;")[0];
            img.onclick = function () {
                if(obj.record === undefined)
                    webUser.delete(this.userId ,this);
                else
                    webUserRecord.delete(this.userRecordId, this);
            };
        }

    }
    console.log("function makeSortableTable called with initial sort: " + sortOrderPropName +" in "+ order + " order.");

    var returnDiv = document.createElement("div");
    returnDiv.innerHTML = "Filter by: ";

    var searchInput = document.createElement("input");
    returnDiv.appendChild(searchInput);

    var newTable = document.createElement("table");
    returnDiv.appendChild(newTable);
    
    addTableHead(newTable, list);
    addTableBody(newTable, list, sortOrderPropName, order, searchInput.value);

    searchInput.onkeyup = function () {
        console.log("search filter changed to " + searchInput.value);
        addTableBody(newTable, list, sortOrderPropName, order, searchInput.value);
    };
    return returnDiv;
}