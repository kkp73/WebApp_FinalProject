function records() {

var content = `<div id="listHere" class="clickSort">
                <h2>Search User Record</h2>
               </div>
              `;
    
    "use strict";
    ajax("json/user_record.json", processData, document.getElementById("listHere"));
    function processData(list) {

        console.log(list);

        var userList = [];

        for (var i = 0; i < list.length; i++) {

            userList[i] = {};
            userList[i].imageLogo = "<img  src='" + list[i].imageLogo + "' style='width:5rem; margin:0.5rem'>";
            userList[i].userEmail = list[i].userEmail;
            userList[i].recordName = list[i].recordName;
            userList[i].totalGames = list[i].totalGames;
            userList[i].runs = list[i].runs;
            userList[i].batAve = list[i].batAve;
            userList[i].debutDate = list[i].debutDate;
        }

        console.log("USER LIST");
        console.log(userList);
        var webUserRecordTable = makeSortableTable(userList, "imageLogo", "Forword", "icons/sortUpDown16.png");
        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp",
            parent: webUserRecordTable.getElementsByTagName('table')[0].rows[0]
        });
        
        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp", // this is just a "non breaking space", placeholder.
            parent: webUserRecordTable.getElementsByTagName('table')[0].rows[0]
        });
        document.getElementById("listHere").appendChild(webUserRecordTable);
    }
    
        var ele = document.createElement("div");
        ele.innerHTML = content;
        return ele;
}

