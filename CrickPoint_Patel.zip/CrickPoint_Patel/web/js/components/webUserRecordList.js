function webUserRecordList() {

    var contentDOM = document.createElement("div");
    contentDOM.classList.add("clickSort");
    ajax("webAPIs/listOtherAPI.jsp", success, contentDOM);
    function success(obj) {

        console.log("listOtherAPI.jsp AJAX successfully returned the following data");
        console.log(obj);

        if (obj.dbError.length > 0) {
            contentDOM.innerHTML += "Database Error Encountered: " + obj.dbError;
            return;
        }

        var heading = Utils.make({
            htmlTag: "h2",
            parent: contentDOM
        });
        Utils.make({
            htmlTag: "span",
            innerHTML: "Web Record List ",
            parent: heading
        });
        var img = Utils.make({
            htmlTag: "img",
            parent: heading
        });
        img.src = CRUD_icons.insert;
        img.onclick = function () { 
            window.location.hash = "#/userRecordInsert";
        };

        var userRecordList = [];
        for (var i = 0; i < obj.webOtherList.length; i++) {
            userRecordList[i] = {};
            userRecordList[i].image = "<img style='width:5rem' src='" + obj.webOtherList[i].image + "'>";
            userRecordList[i].record = obj.webOtherList[i].userRecordId + "&nbsp;" +
                    obj.webOtherList[i].recordName;
            userRecordList[i].totalGames = obj.webOtherList[i].totalGames;
            userRecordList[i].runs = obj.webOtherList[i].runs;
            userRecordList[i].batAvg = obj.webOtherList[i].batAvg;
            userRecordList[i].debutDate = obj.webOtherList[i].debutDate;
            userRecordList[i].WebUserId = obj.webOtherList[i].webUserId;
            userRecordList[i].userEmail = obj.webOtherList[i].userEmail;

            userRecordList[i].errorMsg = obj.webOtherList[i].errorMsg;

            userRecordList[i].errorMsg = obj.webOtherList[i].errorMsg;
        }

        var webUserRecordTable = makeSortableTable(userRecordList, "image","Forword", "icons/sortUpDown16.png");

        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp",
            parent: webUserRecordTable.getElementsByTagName('table')[0].rows[0]
        });
        
        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp",
            parent: webUserRecordTable.getElementsByTagName('table')[0].rows[0]
        });


        contentDOM.appendChild(webUserRecordTable);
    }
    return contentDOM;
}

var webUserRecord = {};
webUserRecord.delete = function (recordId,icon) {
    modalFw.confirm("Do you really want to delete record " + recordId + "? ", callback);
    function callback() {
        
        console.log("icon that was passed into JS function is printed on next line");
        console.log(icon);

        ajax("webAPIs/deleteRecordAPI.jsp?deleteId=" + recordId, APISuccess);
        function APISuccess(obj) {
            console.log("successful ajax call");
            var dataRow = icon.parentNode.parentNode;
            var rowIndex = dataRow.rowIndex - 1;
            var dataTable = dataRow.parentNode;
            dataTable.deleteRow(rowIndex);

            if (obj.errorMsg.length === 0) {
                var msg = "Record " + recordId + " successfully deleted. ";
                console.log(msg);
                modalFw.alert(msg);
            } else {
                console.log("Delete Web API got this error: "+ obj.errorMsg);
                modalFw.alert("Web API successfully called, but got this error from the Web API: " + obj.errorMsg);
            }
        } 
    }
};
