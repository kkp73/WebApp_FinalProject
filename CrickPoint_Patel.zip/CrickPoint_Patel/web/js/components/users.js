function users() {

    var content = `<div id="listHere" class="clickSort">
                    <h2>Search User</h2>
                   </div>
              `;
    
    "use strict"; // turn off the "auto variable declaration" feature of the browser.
    
    ajax("json/users.json", processData, document.getElementById("listHere"));
    function processData(list) {
        // print out JS object/array that was converted from JSON data by ajax function
        console.log(list);

        var userList = [];

        for (var i = 0; i < list.length; i++) {

            userList[i] = {};
            userList[i].image = "<img  src='" + list[i].image + "' style='width:5rem; margin:0.5rem'>";
            userList[i].userEmail = list[i].userEmail;
            userList[i].birthday = list[i].birthday;
            userList[i].membershipFee = list[i].membershipFee;
            userList[i].role = list[i].userRoleId + " " + list[i].userRoleType;
        }

        console.log("USER LIST");
        console.log(userList);
        
        var webUserTable = makeSortableTable(userList, "image","Forword", "icons/sortUpDown16.png");
        
        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp", // this is just a "non breaking space", placeholder.
            parent: webUserTable.getElementsByTagName('table')[0].rows[0]
        });
        
        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp", // this is just a "non breaking space", placeholder.
            parent: webUserTable.getElementsByTagName('table')[0].rows[0]
        });

        document.getElementById("listHere").appendChild(webUserTable);
    }
    var ele = document.createElement("div");
    ele.innerHTML = content;   
    return ele;
}

