var webUserMods = {};

(function () {
    function getDataFromUI(validateObjList) {

        var selTag = validateObjList["userRoleId"].inputBox;

        var userInputObj = {

            "webUserId": validateObjList["webUserId"].inputBox.value,
            "userEmail": validateObjList["userEmail"].inputBox.value,
            "userPassword": validateObjList["userPassword"].inputBox.value,
            "userPassword2": validateObjList["userPassword2"].inputBox.value,
            "image": validateObjList["image"].inputBox.value,
            "birthday": validateObjList["birthday"].inputBox.value,
            "membershipFee": validateObjList["membershipFee"].inputBox.value,

            "userRoleId": selTag.options[selTag.selectedIndex].value,

            "userRoleType": "",
            "errorMsg": ""
        };
        console.log("getDataFromUI - userInputObj on next line");
        console.log(userInputObj);

        return encodeURIComponent(JSON.stringify(userInputObj));
    }
 
    function writeErrorObjToUI(jsonObj, validateObjList) {

        console.log("here is JSON object (holds error messages.");
        console.log(jsonObj);
        validateObjList["userEmail"].errorTd.innerHTML = jsonObj.userEmail;
        validateObjList["userPassword"].errorTd.innerHTML = jsonObj.userPassword;
        validateObjList["userPassword2"].errorTd.innerHTML = jsonObj.userPassword2;
        validateObjList["image"].errorTd.innerHTML = jsonObj.image;
        validateObjList["birthday"].errorTd.innerHTML = jsonObj.birthday;
        validateObjList["membershipFee"].errorTd.innerHTML = jsonObj.membershipFee;
        validateObjList["userRoleId"].errorTd.innerHTML = jsonObj.userRoleId;
        validateObjList["recordError"].innerHTML = jsonObj.errorMsg;

    }

    function makeInputRow(fieldName, promptText, validationTable, validationObjList) {

        var obj = {};
        var row = Utils.make({
            htmlTag: "tr",
            parent: validationTable
        });
        Utils.make({
            htmlTag: "td",
            innerHTML: promptText,
            parent: row
        });
        var inputTd = Utils.make({
            htmlTag: "td",
            parent: row
        });
        obj.inputBox = Utils.make({
            htmlTag: "input",
            parent: inputTd
        });

        obj.errorTd = Utils.make({
            htmlTag: "td",
            parent: row,
            class: "error"
        });

        validationObjList[fieldName] = obj;
    }

    function createValidationArea(validateTable, validateObjList) {

        makeInputRow("webUserId", "User Id", validateTable, validateObjList);
        validateObjList["webUserId"].inputBox.setAttribute("disabled", true);

        makeInputRow("userEmail", "User Email", validateTable, validateObjList);

        makeInputRow("userPassword", "Password", validateTable, validateObjList);
        makeInputRow("userPassword2", "Retype Password", validateTable, validateObjList);
        validateObjList["userPassword"].inputBox.setAttribute("type", "password");
        validateObjList["userPassword2"].inputBox.setAttribute("type", "password");

        makeInputRow("image", "Image URL", validateTable, validateObjList);
        makeInputRow("birthday", "Birthday", validateTable, validateObjList);
        makeInputRow("membershipFee", "Membership Fee", validateTable, validateObjList);
        makeInputRow("userRoleId", "User Role", validateTable, validateObjList);

        var row = Utils.make({
            htmlTag: "tr",
            parent: validateTable
        });
        var saveCell = Utils.make({
            htmlTag: "td",
            parent: row
        });
        var saveButton = Utils.make({
            htmlTag: "button",
            innerHTML: "Save",
            parent: saveCell
        });
        var recordError = Utils.make({
            htmlTag: "td",
            parent: row,
            class: "error"
        });
        Utils.make({
            htmlTag: "td",
            parent: row
        });

        validateObjList["recordError"] = recordError;
        validateObjList["saveButton"] = saveButton;
    }

    webUserMods.insert = function () {

        function insertSave() {

            var myData = getDataFromUI(validateObjList);

            ajax("webAPIs/insertUserAPI.jsp?jsonData=" + myData, processInsert, insertDiv);
            function processInsert(obj) {

                console.log("webUserMods.insert/insertSave/processInsert error msg obj (see next line)");
                console.log(obj);

                if (obj.errorMsg.length === 0) { // success
                    obj.errorMsg = "Record successfully inserted.";
                }

                writeErrorObjToUI(obj, validateObjList);
            }
        }

        var insertDiv = document.createElement("div");
        insertDiv.classList.add("insertArea");

        var validateObjList = [];

        Utils.make({
            htmlTag: "h2",
            innerHTML: "New Web User",
            parent: insertDiv
        });

        var validateTable = Utils.make({
            htmlTag: "table",
            parent: insertDiv
        });

        createValidationArea(validateTable, validateObjList);

        validateObjList["saveButton"].onclick = function () {

            validateObjList["recordError"].innerHTML = " &nbsp; &nbsp; ...";
            insertSave();
        };

        ajax("webAPIs/getRolesAPI.jsp", processRoles, insertDiv);
        function processRoles(obj) {

            if (obj.dbError.length > 0) {
                validateObjList["userRoleId"].errorTd.innerHTML += "Programmer Error: Cannot Create Role Pick List";
            } else {
                var selectDOM = Utils.makePickList({
                    list: obj.roleList,
                    keyProp: "userRoleId",
                    valueProp: "userRoleType"
                });

                var roleInputTd = validateObjList["userRoleId"].inputBox.parentElement;
                roleInputTd.innerHTML = "";
                roleInputTd.appendChild(selectDOM);
                validateObjList["userRoleId"].inputBox = selectDOM;
            }
        }
        return insertDiv;
    };

    webUserMods.update = function (webUserId) {

        function updateSave() {

            var myData = getDataFromUI(validateObjList);
            ajax("webAPIs/updateUserAPI.jsp?jsonData=" + myData, processInsert, updateDiv);
            function processInsert(jsonObj) {

                if (jsonObj.errorMsg.length === 0) { // success
                    jsonObj.errorMsg = "Record successfully updated. ";
                }

                writeErrorObjToUI(jsonObj, validateObjList);
            }
        }

        console.log("webUsers.update called with webUserId " + webUserId);

        var updateDiv = document.createElement("div");
        updateDiv.classList.add("updateArea");

        var validateObjList = [];

        Utils.make({
            htmlTag: "h2",
            innerHTML: "Update Web User",
            parent: updateDiv
        });

        var validateTable = Utils.make({
            htmlTag: "table",
            parent: updateDiv
        });

        createValidationArea(validateTable, validateObjList);

        validateObjList["saveButton"].onclick = function () {

            validateObjList["recordError"].innerHTML = " &nbsp; &nbsp; ...";
            updateSave();
        };

        ajax("webAPIs/getUserByIdAPI.jsp?userId=" + webUserId, gotRecordById, updateDiv);

        function gotRecordById(webUserObj) {
            console.log("gotRecordById, webUserObj is next");
            console.log(webUserObj);

            validateObjList["webUserId"].inputBox.value = webUserObj.webUserId;
            validateObjList["userEmail"].inputBox.value = webUserObj.userEmail;
            validateObjList["userPassword"].inputBox.value = webUserObj.userPassword;
            validateObjList["userPassword2"].inputBox.value = webUserObj.userPassword;
            validateObjList["image"].inputBox.value = webUserObj.image;
            validateObjList["birthday"].inputBox.value = webUserObj.birthday;
            validateObjList["membershipFee"].inputBox.value = webUserObj.membershipFee;

            ajax("webAPIs/getRolesAPI.jsp", processRoles, updateDiv);
            function processRoles(obj) {

                if (obj.dbError.length > 0) {
                    validateObjList["userRoleId"].errorTd.innerHTML += "Programmer Error: Cannot Create Role Pick List";
                } else {

                    console.log("userRoleId is " + webUserObj.userRoleId);
                    var selectDOM = Utils.makePickList({
                        list: obj.roleList,
                        keyProp: "userRoleId",
                        valueProp: "userRoleType",
                        selectedKey: webUserObj.userRoleId

                    });

                    var roleInputTd = validateObjList["userRoleId"].inputBox.parentElement;
                    roleInputTd.innerHTML = "";
                    roleInputTd.appendChild(selectDOM);
                    validateObjList["userRoleId"].inputBox = selectDOM;
                }
            } 
        }
        return updateDiv;
    };
}());