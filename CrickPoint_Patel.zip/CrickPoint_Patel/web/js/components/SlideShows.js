function SlideShows() {

    var content = `
        <p class="slideShow" id="firstSlideId"></p>

        <br/>
          
        <p class="slideShow" id="secondSlideId"></p>

        <br/>
            
        <p class="slideShow" id="thirdSlideId"></p>
    `;

    ajax("json/waterFun.json", processFunList, document.getElementById("firstSlideId"));
    ajax("json/cars.json", processCarList, document.getElementById("secondSlideId"));
    ajax("json/users.json", processUserList, document.getElementById("thirdSlideId"));
    var ele = document.createElement("div");
    ele.innerHTML = content;
    return ele;
}

function processFunList(funList) {
    for (var i = 0; i < funList.length; i++) {
        funList[i].image = funList[i].pic;
        funList[i].caption = funList[i].item;
        console.log("image " + i + " " + funList[i].image);
    }

    console.log("funList after setting image properties");
    console.log(funList);
    var ss = makeSlideShow(funList);
    document.getElementById("firstSlideId").appendChild(ss);
    ss.setPicNum(1);
}

function processCarList(carList) {
    for (var i = 0; i < carList.length; i++) {
        carList[i].image = carList[i].photo;
        carList[i].caption = carList[i].make;
        console.log("image " + i + " " + carList[i].image);
    }

    var ss = makeSlideShow(carList);
    document.getElementById("secondSlideId").appendChild(ss);

    ss.setPicNum(2);
}

function processUserList(userList) {
    console.log(userList);

    for (var i = 0; i < userList.length; i++) {
        userList[i].caption = userList[i].userEmail;
        console.log("image " + i + " " + userList[i].image);
    }

    var ss = makeSlideShow(userList);
    document.getElementById("thirdSlideId").appendChild(ss);
}
