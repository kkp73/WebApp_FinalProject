function webUserList() {

    var contentDOM = document.createElement("div");
    contentDOM.classList.add("clickSort");
    ajax("webAPIs/listUsersAPI.jsp", success, contentDOM);
    function success(obj) {

        console.log("listUsersAPI.jsp AJAX successfully returned the following data");
        console.log(obj);

        if (obj.dbError.length > 0) {
            contentDOM.innerHTML += "Database Error Encountered: " + obj.dbError;
            return;
        }

        var heading = Utils.make({
            htmlTag: "h2",
            parent: contentDOM
        });
        Utils.make({
            htmlTag: "span",
            innerHTML: "Web User List ",
            parent: heading
        });
        var img = Utils.make({
            htmlTag: "img",
            parent: heading
        });
        img.src = CRUD_icons.insert;
        img.onclick = function () {
            window.location.hash = "#/userInsert";
        };

        var userList = [];
        for (var i = 0; i < obj.webUserList.length; i++) {
            userList[i] = {};
            
            userList[i].userCredentials = obj.webUserList[i].userEmail + "<br/> PW (to test Logon): " +
                    obj.webUserList[i].userPassword;
            userList[i].image = "<img style='width:5rem' src='" + obj.webUserList[i].image + "'>";
            userList[i].birthday = obj.webUserList[i].birthday;
            userList[i].membershipFee = obj.webUserList[i].membershipFee;
            userList[i].role = obj.webUserList[i].userRoleId + "&nbsp;" +
                    obj.webUserList[i].userRoleType;
            userList[i].userId = obj.webUserList[i].webUserId;

            userList[i].errorMsg = obj.webUserList[i].errorMsg;
        }
        var webUserTable = makeSortableTable(userList, "image", "Forword", "icons/sortUpDown16.png");

        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp",
            parent: webUserTable.getElementsByTagName('table')[0].rows[0]
        });
        
        Utils.make({
            htmlTag: "th",
            innerHTML: "&nbsp",
            parent: webUserTable.getElementsByTagName('table')[0].rows[0]
        });

        contentDOM.appendChild(webUserTable);
    }

    return contentDOM;
}
var webUser = {};

webUser.delete = function (userId,icon) {
    modalFw.confirm("Do you really want to delete user " + userId + "? ", callback);
    function callback() {
        console.log("icon that was passed into JS function is printed on next line");
        console.log(icon);

        ajax("webAPIs/deleteUserAPI.jsp?deleteId=" + userId, APISuccess);//, messageDOM);
        function APISuccess(obj) {
            console.log("successful ajax call");
            var dataRow = icon.parentNode.parentNode;
            var rowIndex = dataRow.rowIndex - 1;
            var dataTable = dataRow.parentNode;
            dataTable.deleteRow(rowIndex);
            if (obj.errorMsg.length === 0) {
                var msg = "Record " + userId + " successfully deleted. ";
                console.log(msg);
                modalFw.alert(msg);
            } else {
                console.log("Delete Web API got this error: "+ obj.errorMsg);
                modalFw.alert("Web API successfully called, but got this error from the Web API: " + obj.errorMsg);
            }
        }
    }

};
