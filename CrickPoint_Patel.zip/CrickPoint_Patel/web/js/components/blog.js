function blog() {
var content = ` 
    <h2>Cricket Overview.</h2>
    
        <p>
            <a id="cricLink" href="https://en.wikipedia.org/wiki/Cricket">Cricket Wikipedia Page</a> 
            "Cricket is a bat-and-ball game played between two teams of eleven players on a field at 
            the centre of which is a 22-yard (20-metre) pitch with a wicket at each end, each comprising 
            two bails balanced on three stumps. The batting side scores runs by striking the ball bowled 
            at the wicket with the bat (and running between the wickets), while the bowling and fielding 
            side tries to prevent this (by getting the ball to either wicket) and dismiss each batter 
            (so they are "out"). Means of dismissal include being bowled, when the ball hits the stumps 
            and dislodges the bails, and by the fielding side catching the ball after it is hit by the 
            bat, but before it hits the ground. When ten batters have been dismissed, the innings ends 
            and the teams swap roles. The game is adjudicated by two umpires, aided by a third umpire 
            and match referee in international matches. They communicate with two off-field scorers who 
            record the match's statistical information." From Cricket wikipedia Page.
        </p>
    
    <br/>
    
    <h2>Homework 1</h2>
    
    <h3>Web design experience</h3>
        
        <p>
            This is unique experiences as of now, also overwhelming to learn and implement 
            too many new things at once. When I started my webpage assignment, I was not 
            aware of what things will I need or not, but as I start thinking more in details 
            everything starts to popup in my mind one by one. It took few hours to get to 
            learn and read through given materials and reference supplies. Overall this was 
            a new learning experience for me. 
        </p>  
    
    <h3>What I found Easy or Hard?</h3>
        <p>
            During this assignment so many resources were provided for me to study, and 
            description of the homework was detailed and easy to follow. So, completing 
            the homework assignment with the help of given resources made my work easy. 
            There were too many documents, and weblinks to follow which were confusing 
            for me, or I can say the way all material was spread out made it more confusing 
            to keep track of it. Also, it was Hard to organize all the reference materials 
            and follow it at certain level made my work harder then it supposed to be. 
        </p>

    <br/>

    <h2>Homework 3.a</h2>
    
    <h3>What I did in this Homework?</h3>
        <p> 
            In this Homework I have learned about the JavaScript, json, and AJAX. I have
            studied JavaScript, Json, and AJAX from the course website as well as w3schools.com
            After the learning, I have used the sample code to create a slideshow of pictures
            provided by Dr. Sally K. I have modified sample code to fit my changes to this homework.
        </p>
    
    <h3>What I found Easy?</h3>
        <p> 
            In homework 3 I didnt found much thats easy. but Sample code and instruction at some 
            point was very easy to follow. Pictures were provided by the Dr. Sally K which was easy.
            Using the sample code was very helpful.
        </p>
    
    <h3>What I found hard/confusing?</h3>
        <p>
            Instruction on given point were to confusing. Work needs to be done for this homework was
            not clear. Completeing the home work with instruction was kind of more confusing the hard.
        </p>
    
    <h3>What was valuable?</h3>
        <p> 
            Learning experience is valuable. Also Knowledge of Javascript, Json, AJAX is very important.
            Following the instructions and finishing the work right is also equally important.
        </p>
    
    <br/>
    
    <h2>Homework 3.b: Database</h2>
    
    <h3>Database experience:</h3>
        <p> 
            In homework 3.b Database is kind of fun and informative. This homewoek has tought me many 
            new things. Working with database is not as easy as I was thinking. Work it self is not 
            hard but it is tricky. Once you connect each dots the homework becomes easy and fun. 
            Learning about creating table, altering the table and adding data to the table was 
            intresting and informative learning experience. 
        </p>
    
    <h3>Link to PDF document and hardness of the homework:</h3>
        <p> 
            Click <a target="_blank" href='pics/Patel_database.pdf'>here</a> to see my database document.
            I found this homework fairly easy compare to previous homeworks. Following the guideline was
            very easy for this homework. instruction was given was easy to follow. only thing I found hard
            in this homework is to setting up my database and making a foraign key from web_user table.
        </p>
    
    <br/>
    
    <h2>Homework 4 Display Data</h2>
    
    <h3>What I did in this Homework?</h3>
        <p> 
            I have used everything that I have learned in this course so far. Such as JavaScript, Json,
            AJAX, Frontend coding as well as Back end coding. Also I have fixed the previous errors from
            other homeworks. I have used the sample code for to complette this assignment. I have used 
            the sample code to create a slideshow of pictures provided by Dr. Sally K. I have modified 
            sample code to fit my changes to this homework. I have also mmodified my Other table accordingly.
            
        </p>
    
    <h3>What I found Easy?</h3>
        <p> 
            In homework 4 I didnt found much thats easy. but Sample code and instruction at some 
            point was very easy to follow. Pictures were provided by the Dr. Sally K which was easy.
            Using the sample code was very helpful. I did took tomuch time to complete this homework.
        </p>
    
    <h3>What I found hard/confusing?</h3>
        <p>
            I had fallbehind for this homework which make everything hard for to catchup. Backward sort
            was hard for me to figur it out. but at the end hard work is what teaches us the most. 
        </p>
    
    <h3>What was valuable?</h3>
        <p> 
            Everything I have learnead during this assigmnet was valuable to me. Specially not giving up
            even when I miss the deadline for this assignment and tried my best to catch up with the class.
            I think my trying didi get me the result that I was hoping for and I will catch up with the class
            soon. 
        </p>
    
    <br/>
    
    <h2>Homework 5 Web APIs</h2>
    
    <h3>What important concepts I learned this week?</h3>
        <p> 
            I have learned and revise many topics this while doing this homework. Such as JavaScript, Json,
            AJAX, Frontend coding as well as Back end coding. Also I have fixed the previous errors from
            other homeworks. I have used the sample code for to complette this assignment. I have used 
            the sample code to create a slideshow of pictures provided by Dr. Sally K. I have modified 
            sample code to fit my changes to this homework. I have also mmodified my Other table accordingly.
            
        </p>

    <h3>What I found Easy?</h3>
        <p> 
            Home Work 5 was fairly easy for me because compare to Homework 4 I had less stress also I was 
            feeling more relaxed as We didn't had new homework due this week. Which gave me time to catch 
            up with the class.
        </p>

    <h3>Link to Word document:</h3>
        <p>
            Click <a target="_blank" href='pics/List_of_Errors.pdf'>here</a> to see my database document. 
        </p>

    <h3> Relative links to invoke the two Web APIs users and other</h3>
        <p> 
            Click <a href='webAPIs/listUsersAPI.jsp'>here</a> for the Web API that lists Web Users from my DB
            Click <a href='webAPIs/listOtherAPI.jsp'>here</a> for the Web API that lists data from my Records Table 
        </p>
    
    <br/>
    
    <h2>Homework 7 Insert</h2>
    
    <h3>What important concepts I learned this week?</h3>
        <p> 
            While Doing the insert Homework I have got chance to revise many of the previously covered topics.
            Such as Server side code and Client side code, as well as Javascripts, database work, ajax calls 
            Frontend coding as well as Back end coding. Also I have fixed the previous errors from
            other homeworks. I have used the sample code for to complete this assignment. I have used 
            the sample code to insert players record for my homework whcih was provided by Dr. Sally K. I have modified 
            sample code to fit my changes to this homework. I have changed my database after getting feedback from databse
            homework so my current database might not match the description I provided in Database assignment.            
        </p>
    
    <h3>What I found Easy?</h3>
        <p> 
            While I was doing the homework 7 I have broke the previouse functality of my website. I have not got 
            chance to fix those errors yet, but I will have it fixed soon. Also this homework was made easy by
            using the sample code. it had much work to to but I have try to preplan for homework 8 as well while 
            doing this homework. That means I should be able to finish next homework on time.
        </p>
    
    <br/>
    
    <h2>Homework 8 Update</h2>
    
    <h3>What important concepts I learned this week?</h3>
        <p> 
            I have changed my database after getting feedback from database homework so my current database might
            not match the description I provided in Database assignment. While Doing the insert Homework I have 
            got chance to revise many of the previously covered topics. Such as Server side code and Client 
            side code, as well as Javascripts, database work, ajax calls Frontend coding as well as Back end coding.
            I have used the sample code to complete this assignment. I have used the sample code to update players 
            record for my homework which was provided by Dr. Sally K. I have modified sample code to fit my changes to this homework.             
        </p>
    
    <h3>What I found Easy?</h3>
        <p> 
            While I was doing the homework 7 I have broke the previouse functality of my website. I have not got 
            chance to fix those errors yet, but I will have it fixed soon. As I mentioned before that I had preplan for homework 8
            as well while doing homework 7. That made my life so much easier to complete Update homework on time. Here is the Link 
            <a target="_blank" href='pics/Patel_database.pdf'>here</a> to see my database document. "Which is not updated to the recent changes." 
        </p>
    
    <br/>
    
    <h2>Homework 9 Delete</h2>
    
    <h3>What important concepts I learned this week?</h3>
        <p> 
            I have try to fix all of my previouse homeworks according to the feedback from TA and Proffessor. I have tried to impliment 
            the changes according to each individual homework frame work. That way I can be ready to sibmit my final project as well. 
            While fixing previouse homeworks I have revised all the key concept we have learned during the entier semester.
        </p>
    
    <h3>What I found Easy?</h3>
        <p> 
            AS this is our last homework, and Dr. Sally K mentioned that this homework is eaiser in compare to other homework.
            overall this homework was easy, which game me chance to fix my other homework as well.
        </p>
    
    `;
        var element = document.createElement("div");
        element.innerHTML = content;
        return element;
        }