function home () {
var content = `
    <h2>Media Quary Image:</h2>
    <img src="pics/cricket2_700x436.jpg" class="image2"/>
    <img src="pics/cricket3_1000x562.jpg" class="image1"/>
    
    <h2>Website Functionality</h2>
        <p>
            Players or Team can use this website to track records of their performance in 
            Game of cricket. User will be able to insert, update, or delete the record and 
            Players. Also User will be ablw to Create account, Update, delete Account of 
            the player. Each user will get assigned to a Role. 
        </p>

            
    <h3>Database Description: Updated 11/28/2020</h3>
        <ul>
            <li>Table 1: Players</li>
                <ol>
                    <li>- Players ID: Unique auto increments based on registration time</li>
                    <li>- User Email: String</li>
                    <li>- User Password: String</li>
                    <li>- Date of Birth: Date Format</li>
                    <li>- Players Image: String</li>
                    <li>- Membership Fee: Decimal</li>
                    <li>- Players Role ID: int</li>
                </ol>
    
            <br/>
                
            <li>Table 2: Records</li>
                <ol>
                    <li>- Player Record ID: Unique auto increments based on registration time</li>
                    <li>- Record Name: String</li>
                    <li>- Record Logo: String</li>
                    <li>- Total Games: int</li>
                    <li>- Runs: int</li>
                    <li>- Bating Average: Decimal</li>
                    <li>- Debut Date: Date format</li>
                    <li>- Player ID: String from Players Table</li>
                </ol>

            <br/>

            <li>Table 3: Role</li>
                <ol>
                    <li>- Players Role ID: Unique auto increments based on registration time</li>
                    <li>- Players Role: String</li>
                </ol>
        </ul>
    `;
        var element = document.createElement("div");
        element.innerHTML = content;
        return element;
        }