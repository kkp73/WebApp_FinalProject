var account = {};

(function ( ) { 

    account.logon = function ( ) {
        
        var container = document.createElement("div"); //outermost container
        container.classList.add("form");
        var inputContainer = document.createElement("div"); //contain the input elements
        var profContainer = document.createElement("div"); //contain the user's profile information

        //Create a Label for user to enter an email address
        var emailLabel = document.createElement("span");
        emailLabel.innerHTML = "Email: ";
        inputContainer.appendChild(emailLabel);

        //create an input element to take in the email address
        var emailInput = document.createElement("input");
        inputContainer.appendChild(emailInput);
        
        //Create a label for user to enter a password
        var passLabel = document.createElement("span");
        passLabel.innerHTML = "Password: ";
        inputContainer.appendChild(passLabel);

        //create an input element to take in the password
        var passwordInput = document.createElement("input");
        passwordInput.setAttribute("type", "password");
        inputContainer.appendChild(passwordInput);

        //add a submit button that calls the logon API onclick with the user specified email and password
        var submitButton = document.createElement("button");
        submitButton.innerHTML = "Submit";
        submitButton.onclick = function () {
            ajax("webAPIs/logonAPI.jsp?user_email=" + escape(emailInput.value) + "&user_password=" + escape(passwordInput.value), processLogon, profContainer);
            function processLogon(obj) {
                profContainer.innerHTML = buildProfile(obj);
            }
        };
        inputContainer.appendChild(submitButton);

        //append the child containers and return the outer container
        container.appendChild(inputContainer);
        container.appendChild(profContainer);
        return container;
    };

    account.getProfile = function ( ) {
        //This function call the getProfile API to get the currently logged in user's info and displays it
        
        var profContainer = document.createElement("div");
        profContainer.classList.add("form");
        ajax("webAPIs/getProfileAPI.jsp", processGetProfile, profContainer);
        function processGetProfile(obj) {
            profContainer.innerHTML = buildProfile(obj);
        }
        return profContainer; //return the container
    };

    account.logoff = function ( ) {
        //This function calls the logoff API to log the current user out and displays message
        
        var container = document.createElement("div"); //create a container for the message
        container.classList.add("form");
        ajax("webAPIs/logoffAPI.jsp", processLogoff, container);
        function processLogoff(obj) {
            container.innerHTML = buildProfile(obj);
        }
        return container; //return the container
    };

    function buildProfile(userObj) {
        //This function takes an obj containing the user's data and 
        //generate formatted collection of UI elements to display that data or an error message
        
        var msg = "";
        if (userObj.errorMsg.length > 0) { //If the user data isn't there then just return an error message
            msg += "<strong>Error: " + userObj.errorMsg + "</strong>";
        } else { //otherwise, create the UI
            msg += "<strong>Welcome Web User " + userObj.webUserId + "</strong>";
            msg += "<br/> Birthday: " + userObj.birthday;
            msg += "<br/> MembershipFee: " + userObj.membershipFee;
            msg += "<br/> User Role: " + userObj.userRoleId + " " + userObj.userRoleType;
            msg += "<p> <img src ='" + userObj.image + "'> </p>";
        }
        return msg;
    }

}( ));

